#---------------------------------------------------#
#Title:ToDo
#Dev: JHarvey
#Date: Nov 13, 2018
#ChangeLog(who, when, what):
#       JHarvey, Nov 13, 2018, Created Script
#       jharvey, nov 19, 2018, revised script with multiple options
#               used code provided by R Root
#       jharvey, nov 26, 2018, revised script:
#           - created classes: InputOutput, DisplayData, EditData
#           - created functions RedFile(), WriteFile(), ShowIndexedData(), ShowRow()
#           -    AddRow() and DeleteRow()
#---------------------------------------------------#
#######################################################
#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# DoMore = loop variable for continuing to enter data, not really necessary
# strNewTask = task decription for a new row from user
# strNewPriority = priority for a new row from user
# intTaskIndex - gets task number for deletion
# lstTable = A dictionary that acts as a 'table' of rows
# strChoice = Capture the user option selection

# ---Classes and Methods --- #
#   InputOutput.RedFile()InputOutput.WriteFile(); read and write to and from files
#   DisplayData.ShowIndexedData; shows a formatted row of data
#   DisplayData.ShowRow; shows formatted table with rows
#   EditData.AddRow() EditData.DeleteRow(), adds and deletes rows from data

#-- Input/Output --#
# User can see a Menu (Choice 1)
# User can see data (Choice 2)
# User can insert or delete data(Choice 3 and 4)
# User can save to file (Step 5)


#-- Processing --#

# Step 1. Introductory Variables are set, file is uploaded
# Step 2. Classes and Methods defined
# Step 3. Upload Data File
# Step 4. Iterate through user choices
# Step 5. Terminate
##########################################################

#--- Step 1 ---- Set Introductory Variables ---
lstTable = []  # carries data and exchanges with methods
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"

DoMore = "Y"   # initializes the while loop to proceed

#--- Step 2 ----- Define Classes, methods and functions ----

class InputOutput(object):
    # methods in this import and export data

    @staticmethod
    def ReadFile(inputDataFile, uploadLstTable):
        #this method reads data from a file
        #set up variables
        strData = ""
        dicRow = {}

        #open the file and read the data
        strData = open(inputDataFile,"r") #opens file with name of "test.txt"
        for line in strData:
            currentline = line.strip().split(",")
            newDicRow = {"Task": currentline[0],"Priority":currentline[1]}
            uploadLstTable.append(newDicRow)
        strData.close()

    @staticmethod
    def WriteFile(outputDataFile):
        #this method writes the data to a file in CSV format
        #variables for comma and carriage return to create a tab delim file
        strComma = ","
        strCarRtrn = "\n"

        #open the file to write the data
        WriteFileObject = open(outputDataFile, "a")  #reopens the file to write the data

        #obtain each data element, write it to the file separated by commas
        for row in lstTable:
            WriteFileObject.writelines(row["Task"])
            WriteFileObject.writelines(strComma)
            WriteFileObject.writelines(row["Priority"])
            WriteFileObject.writelines(strCarRtrn)

        #close the file
        WriteFileObject.close()
        #close the file


class DisplayData(object):
    # methods in this class display data

    @staticmethod
    def ShowIndexedData(currentTable):
        #his method displays all loaded data with an index number for each row
        intRowNum = 1
        #show the rows with the index number
        for row in currentTable:
            print("Task #", intRowNum,"\t\tTask:...", row["Task"],"\t\t\tPriority:...",row["Priority"])
            intRowNum = intRowNum + 1

    @staticmethod
    def ShowRow(rowNumber, currentTable):
        #this method displays a row with index number and column names
        print("\n\nHere's your entry:\n")
        showRow = currentTable [(rowNumber-1)]
        print("Task #", rowNumber, "\t\tTask:...", showRow["Task"], "\t\t\tPriority:...", showRow["Priority"])


class EditData(object):
    #methods in this class modify data

    @staticmethod
    def AddRow(col1, col2, currentTable):
        #this method adds a row to the dataset
        newDicRow = {"Task": col1, "Priority": col2}
        currentTable.append(newDicRow)

    @staticmethod
    def DeleteRow(rowNumber, currentTable):
        #this method deletes a row from the dataset
        del currentTable [(rowNumber-1)]


#Prompt for the while variable:
print("\n\tThis program allows you to update your 'To Do' list and save it to a file")
DoMore = input("\tPress any key to get started")


#--- Step 3 ----- Upload the data from a file ----
InputOutput.ReadFile(objFileName, lstTable)

#---- Step 4 ---- Get User Choices
while DoMore != "N":
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Choice 1 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Here's the current 'to do' list:\n\n")
        #call output for the current data
        DisplayData.ShowIndexedData(lstTable)

    # Choice 2 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        #obtain new data
        input("Add a new task and it's associated priority at the prompts that follow (Select Enter)\n\n.")

        strNewTask = input("New Task Description.....") # get new task from user
        strNewPriority = input("New Priority Level.....")# get new priority from user

        EditData.AddRow(strNewTask, strNewPriority , lstTable)  #adds tthe row to the table
        DisplayData.ShowRow(len(lstTable), lstTable)     # shows the new row to the user

        continue

    # Choice 3 - Remove an item from the list/Table
    elif (strChoice == '3'):
        input("Hit 'enter' to display the current task list and select a row to delete:\n")

        DisplayData.ShowIndexedData(lstTable)  #displays the current data
        intTaskIndex = int(input("\nEnter the Task # of the task to delete...."))  #prompt user for row number
        DisplayData.ShowRow(intTaskIndex, lstTable)  #displays the row selected
        EditData.DeleteRow(intTaskIndex, lstTable) # passes the data to the function to delete the row

        continue

   # Choice 4 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        input("\nYou've choosen to save the file.  Carefully depress the enter key to perform the file save\n")
        InputOutput.WriteFile(objFileName)

        continue


    # Choice 5 - exit the program
    elif (strChoice == '5'):
        break
