#---------------------------------------------------#
#Title:ToDo
#Dev: JHarvey
#Date: Nov 13, 2018
#ChangeLog(who, when, what):
#       JHarvey, Nov 13, 2018, Created Script
#---------------------------------------------------#
#
#######################################################
# Functional DESCRIPTION
# this program allows users to interact with a 'to do' list - it uploads the existing
# list and allows them to choose:
# 1. to review data
# 2. to add data
# 3. to remove data
# 4. to save the file
# 5. to exit the program and save data

# OPERATIONAL DESCRIPTION
#  1. Introductory Variables are set, file is uploaded
#  2. Provides choices for data maniupulation
#  3. User manipulates data, and opts to end program when desired
#  4. Terminate
#######################################################

# 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   JHarvey, Nov 19 2018, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# DoMore = variable to continue or discontinue while loop.  Completely unecessary but I don't want to mess with it now
# Step 4 ONLY:
# newDicRow = new row for lstTable, data entered by user, keys are "Task" and "Priority"
# strTask = task entered by the user newDicRow
# strPriority = priority entered by the user for newDicRow
# Step 5 ONLY:
# intRowNum = creates a row number to display for each DicRow; intRowNum is incremented to be one more than
#             the index number of each item in lstTable, so the user isn't confused by Row #0
# Step 5 ONLY:
#strComma = "," = provides a comma for separating values in the file
#strCarRtrn ="\n" = provides a carriage return for separating values in the file

# -- Input/Output --#
# STEP 1 - Program automatically loads pre-=named file
# STEP 4 - User can input data
# STEP 5 - User can delete data
# STEP 6 - User can save data

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------



# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

#declare the predetermined file name and set up variables
objFileName = "C:\_PythonClass\Assignment05\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

#### print(lstTable)
#### input("wait!")

#open the file and read the data
strData = open(objFileName,"r") #opens file with name of "test.txt"
for line in strData:
    currentline = line.strip().split(",")
    newDicRow = {"Task": currentline[0],"Priority":currentline[1]}
    lstTable.append(newDicRow)

#close the file
strData.close()

#Prompt for the while variable:
print("\tThis program allows you to update your 'To Do' list and save it to a file")
DoMore = input("\tPress any key to get started")


#Step 2 - Display a menu of choices to the user
while DoMore != "N":
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Here's your current 'to do' list:\n\n")
        #output the current data
        for row in lstTable:
            print("Task:...", row["Task"],"\t\t\tPriority:...",row["Priority"])

        #pause to allow consideration by the user
        input("\n\nPress any key to return to the main menu...")

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        #obtain new data
        input("You can enter each new task and it's associated priority at the prompts that follow.  Hit any key to start\n\n")

        #get the dictionary items from the user
        strTask = input("Task Description.....")
        strPriority = input("Priority Level.....")

        #create the dictionary and append to the table
        newDicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(newDicRow)

        #allow the user to review
        print("\n\nHere's your entry:\n")
        print("Task:...", newDicRow["Task"], "\t\t\tPriority:...", newDicRow["Priority"])

        #pause to allow consideration by the user
        input("\n\nPress any key to return to the main menu...")
        continue


    # 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5
    # Step 5 - Remove an item from the list/Table
    elif (strChoice == '3'):
        input("\nYou can delete an 'To Do' item from the list using the index numbers.  Hit any key to start\n")
        print("Here's the current task list:\n")

        #initiate index number for the user to select rows for deletion
        intRowNum = 1

        #show the rows with the index number
        for row in lstTable:
            print("Task #", intRowNum,"\t\tTask:...", row["Task"],"\t\t\tPriority:...",row["Priority"])
            intRowNum = intRowNum + 1

        #get the users choice
        intTaskIndex = int(input("\nEnter the Task # of the task to delete...."))

        # allow the user to review and delete the selected row
        print("\nYou chose this row:\n\n")
        print(lstTable[(intTaskIndex-1)])
        del lstTable [(intTaskIndex-1)]

        #pause to allow consideration by the user
        input("\n\nPress any key to return to the main menu...")
        continue


    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        input("\nYou've choosen to save the file.  Hit any key to perform the file save\n")

        #variables for comma and carriage return to create a tab delim file
        strComma = ","
        strCarRtrn = "\n"

        #open the file to write the data
        WriteFileObject = open(objFileName, "a")  #reopens the file to write the data

        #obtain each data element, write it to the file separated by commas
        for row in lstTable:
            WriteFileObject.writelines(row["Task"])
            WriteFileObject.writelines(strComma)
            WriteFileObject.writelines(row["Priority"])
            WriteFileObject.writelines(strCarRtrn)

        #close the file
        WriteFileObject.close()

        continue




    elif (strChoice == '5'):
        break  # and Exit the program
